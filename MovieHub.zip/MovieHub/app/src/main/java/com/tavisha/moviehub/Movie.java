package com.tavisha.moviehub;

public class Movie {
    private String id;
    private String name;
    private String description;
    private String review;
    private float rating;

    public Movie() {
        // Empty constructor needed for Firestore
    }

    public Movie(String name, String description, String review, float rating) {
        this.name = name;
        this.description = description;
        this.review = review;
        this.rating = rating;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }
}

