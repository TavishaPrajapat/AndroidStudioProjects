package com.tavisha.moviehub;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class EditMovieActivity extends AppCompatActivity {
    private EditText editMovieNameET, editMovieDescriptionET, editMovieReviewET;
    private RatingBar editMovieRatingBar;
    private Button updateMovieBtn, deleteMovieBtn, returnToMainBtn;

    private FirebaseFirestore db;
    private DocumentReference movieRef;
    private String movieId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_movie);

        db = FirebaseFirestore.getInstance();

        movieId = getIntent().getStringExtra("movieId");
        if (movieId == null) {
            Toast.makeText(this, "Error: Movie not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        movieRef = db.collection("Movies").document(movieId);

        editMovieNameET = findViewById(R.id.editMovieNameET);
        editMovieDescriptionET = findViewById(R.id.editMovieDescriptionET);
        editMovieReviewET = findViewById(R.id.editMovieReviewET);
        editMovieRatingBar = findViewById(R.id.editMovieRatingBar);
        updateMovieBtn = findViewById(R.id.updateMovieBtn);
        deleteMovieBtn = findViewById(R.id.deleteMovieBtn);
        returnToMainBtn = findViewById(R.id.returnToMainBtn);

        loadMovieData();

        updateMovieBtn.setOnClickListener(v -> updateMovie());
        deleteMovieBtn.setOnClickListener(v -> deleteMovie());
        returnToMainBtn.setOnClickListener(v -> finish());
    }

    private void loadMovieData() {
        movieRef.get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        Movie movie = documentSnapshot.toObject(Movie.class);
                        if (movie != null) {
                            editMovieNameET.setText(movie.getName());
                            editMovieDescriptionET.setText(movie.getDescription());
                            editMovieReviewET.setText(movie.getReview());
                            editMovieRatingBar.setRating(movie.getRating());
                        }
                    } else {
                        Toast.makeText(EditMovieActivity.this, "Movie not found", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(EditMovieActivity.this, "Error loading movie data", Toast.LENGTH_SHORT).show();
                    finish();
                });
    }

    private void updateMovie() {
        String name = editMovieNameET.getText().toString().trim();
        String description = editMovieDescriptionET.getText().toString().trim();
        String review = editMovieReviewET.getText().toString().trim();
        float rating = editMovieRatingBar.getRating();

        if (name.isEmpty() || description.isEmpty() || review.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Movie updatedMovie = new Movie(name, description, review, rating);

        movieRef.set(updatedMovie)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(EditMovieActivity.this, "Movie updated successfully", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(EditMovieActivity.this, "Error updating movie", Toast.LENGTH_SHORT).show());
    }

    private void deleteMovie() {
        movieRef.delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(EditMovieActivity.this, "Movie deleted successfully", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(EditMovieActivity.this, "Error deleting movie", Toast.LENGTH_SHORT).show());
    }
}

