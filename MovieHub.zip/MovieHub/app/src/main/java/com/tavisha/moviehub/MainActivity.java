package com.tavisha.moviehub;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {
    private EditText movieNameET, movieDescriptionET, movieReviewET;
    private RatingBar movieRatingBar;
    private Button addMovieBtn, viewMoviesBtn;
    private TextView welcomeTV;

    private FirebaseFirestore db;
    private CollectionReference moviesRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();
        moviesRef = db.collection("Movies");

        // Initialize UI elements
        welcomeTV = findViewById(R.id.welcomeTV);
        movieNameET = findViewById(R.id.movieNameET);
        movieDescriptionET = findViewById(R.id.movieDescriptionET);
        movieReviewET = findViewById(R.id.movieReviewET);
        movieRatingBar = findViewById(R.id.movieRatingBar);
        addMovieBtn = findViewById(R.id.addMovieBtn);
        viewMoviesBtn = findViewById(R.id.viewMoviesBtn);

        String userName = getIntent().getStringExtra("userName");
        if (userName != null && !userName.isEmpty()) {
            welcomeTV.setText("Welcome, " + userName + "!");
        }

        addMovieBtn.setOnClickListener(v -> addMovie());
        viewMoviesBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ViewMoviesActivity.class);
            startActivity(intent);
        });
    }

    private void addMovie() {
        String name = movieNameET.getText().toString().trim();
        String description = movieDescriptionET.getText().toString().trim();
        String review = movieReviewET.getText().toString().trim();
        float rating = movieRatingBar.getRating();

        if (name.isEmpty() || description.isEmpty() || review.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Movie movie = new Movie(name, description, review, rating);

        moviesRef.add(movie)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(MainActivity.this, "Movie added successfully", Toast.LENGTH_SHORT).show();
                    clearInputFields();
                })
                .addOnFailureListener(e -> Toast.makeText(MainActivity.this, "Error adding movie", Toast.LENGTH_SHORT).show());
    }

    private void clearInputFields() {
        movieNameET.setText("");
        movieDescriptionET.setText("");
        movieReviewET.setText("");
        movieRatingBar.setRating(0);
    }
}

