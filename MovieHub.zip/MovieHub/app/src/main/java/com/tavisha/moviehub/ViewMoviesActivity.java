package com.tavisha.moviehub;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class ViewMoviesActivity extends AppCompatActivity {

    private ListView moviesListView;
    private List<Movie> movieList;
    private ArrayAdapter<Movie> adapter;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_movies);

        moviesListView = findViewById(R.id.moviesListView);
        movieList = new ArrayList<>();
        db = FirebaseFirestore.getInstance();

        adapter = new ArrayAdapter<Movie>(this, R.layout.movie_list_item, R.id.movieNameTV, movieList) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if (convertView == null) {
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.movie_list_item, parent, false);
                }

                Movie movie = getItem(position);
                if (movie != null) {
                    TextView nameTV = convertView.findViewById(R.id.movieNameTV);
                    TextView descriptionTV = convertView.findViewById(R.id.movieDescriptionTV);
                    TextView reviewTV = convertView.findViewById(R.id.movieReviewTV);
                    RatingBar ratingBar = convertView.findViewById(R.id.movieRatingBar);

                    nameTV.setText(movie.getName());
                    descriptionTV.setText(movie.getDescription());
                    reviewTV.setText(movie.getReview());
                    ratingBar.setRating(movie.getRating());
                }

                return convertView;
            }
        };

        moviesListView.setAdapter(adapter);

        moviesListView.setOnItemClickListener((parent, view, position, id) -> {
            Movie selectedMovie = movieList.get(position);
            Intent intent = new Intent(ViewMoviesActivity.this, EditMovieActivity.class);
            intent.putExtra("movieId", selectedMovie.getId());
            startActivity(intent);
        });

        loadMovies();
    }

    private void loadMovies() {
        db.collection("Movies").get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    movieList.clear();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        Movie movie = document.toObject(Movie.class);
                        movie.setId(document.getId());
                        movieList.add(movie);
                    }
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> Toast.makeText(ViewMoviesActivity.this, "Error loading movies", Toast.LENGTH_SHORT).show());
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadMovies();
    }
}


